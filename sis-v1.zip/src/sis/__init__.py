"""Static Irreversibility Scanner (SIS) v1.0.0"""
__version__ = "1.0.0"
__author__ = "SIS Team"