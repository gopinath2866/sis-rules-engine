
# SIS API Documentation

## Endpoint
`POST /v1/scan`

## Request Headers

## Request Body
```json
{
  "scan_id": "uuid",
  "files": [
    {
      "name": "main.tf",
      "type": "terraform",
      "content": "resource \"aws_s3_bucket\" \"example\" {}"
    }
  ]
}
{
  "scan_id": "uuid",
  "timestamp": "2024-01-01T00:00:00Z",
  "scanner_version": "1.0.0",
  "findings": [],
  "summary": {
    "total_files": 1,
    "total_findings": 0,
    "by_type": {
      "IRREVERSIBLE_IDENTITY_BINDING": 0,
      "IRREVERSIBLE_DECISION": 0,
      "ADMIN_OVERRIDE_DEPENDENCY": 0
    }
  },
  "errors": []
}