# Static Irreversibility Scanner (SIS) v1.0.0

Deterministic pattern scanner for irreversible infrastructure decisions.

## Overview
The Static Irreversibility Scanner (SIS) is a sealed, deterministic artifact that scans infrastructure-as-code manifests for patterns indicating irreversible decisions, identity bindings, or admin override dependencies.

## Features
- **25 Deterministic Rules**: Pattern-based, no inference
- **Stateless API**: JSON in/out, no persistence
- **Multi-Format Support**: Terraform, CloudFormation, Kubernetes, Docker Compose, ARM
- **Sealed Logic**: No external dependencies, no telemetry

## Quick Start
```bash
docker build -t sis:v1.0.0 .
docker run -p 8000:8000 sis:v1.0.0